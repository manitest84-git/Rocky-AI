--
-- PostgreSQL database dump
--

\restrict ANljeK0JClRIe1d95VUe2qf7hrgoZ1dlhifW6NwRbXiKFov25nVjwd0A4Z2XjPw

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg12+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: automation_routines; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.automation_routines (
    id integer NOT NULL,
    routine_name character varying(255) NOT NULL,
    icon character varying(50) DEFAULT 'zap'::character varying,
    description text,
    actions jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.automation_routines OWNER TO rocky_admin;

--
-- Name: automation_routines_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.automation_routines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.automation_routines_id_seq OWNER TO rocky_admin;

--
-- Name: automation_routines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.automation_routines_id_seq OWNED BY public.automation_routines.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.calendar_events (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    location character varying(255),
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    attendees text[],
    agenda text,
    action_items jsonb DEFAULT '[]'::jsonb,
    recurrence_rule character varying(100) DEFAULT 'NONE'::character varying,
    category character varying(50) DEFAULT 'Work'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar_events OWNER TO rocky_admin;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calendar_events_id_seq OWNER TO rocky_admin;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.calendar_events_id_seq OWNED BY public.calendar_events.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(50) NOT NULL,
    content text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.conversations OWNER TO rocky_admin;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversations_id_seq OWNER TO rocky_admin;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: critical_vault; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.critical_vault (
    id integer NOT NULL,
    user_id integer NOT NULL,
    data_category character varying(255) NOT NULL,
    encrypted_value text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.critical_vault OWNER TO rocky_admin;

--
-- Name: critical_vault_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.critical_vault_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.critical_vault_id_seq OWNER TO rocky_admin;

--
-- Name: critical_vault_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.critical_vault_id_seq OWNED BY public.critical_vault.id;


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.financial_transactions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type character varying(20) DEFAULT 'expense'::character varying NOT NULL,
    category character varying(100) DEFAULT 'General'::character varying NOT NULL,
    amount numeric(12,2) NOT NULL,
    merchant character varying(255),
    transaction_date date DEFAULT CURRENT_DATE NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.financial_transactions OWNER TO rocky_admin;

--
-- Name: financial_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.financial_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_transactions_id_seq OWNER TO rocky_admin;

--
-- Name: financial_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.financial_transactions_id_seq OWNED BY public.financial_transactions.id;


--
-- Name: llm_feature_routes; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.llm_feature_routes (
    id integer NOT NULL,
    feature_key character varying(100) NOT NULL,
    feature_name character varying(150) NOT NULL,
    description text NOT NULL,
    primary_provider_id integer NOT NULL,
    primary_model character varying(100) NOT NULL,
    fallback_provider_id integer,
    fallback_model character varying(100),
    system_prompt_override text,
    temperature_override numeric(3,2),
    max_tokens_override integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_feature_routes OWNER TO rocky_admin;

--
-- Name: llm_feature_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.llm_feature_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_feature_routes_id_seq OWNER TO rocky_admin;

--
-- Name: llm_feature_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.llm_feature_routes_id_seq OWNED BY public.llm_feature_routes.id;


--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.llm_providers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    provider_type character varying(50) NOT NULL,
    base_url text NOT NULL,
    api_key_encrypted text,
    default_model character varying(100) NOT NULL,
    available_models jsonb DEFAULT '[]'::jsonb,
    temperature numeric(3,2) DEFAULT 0.70,
    max_tokens integer DEFAULT 2048,
    timeout_seconds integer DEFAULT 30,
    is_active boolean DEFAULT true,
    is_system boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_providers OWNER TO rocky_admin;

--
-- Name: llm_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.llm_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_providers_id_seq OWNER TO rocky_admin;

--
-- Name: llm_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.llm_providers_id_seq OWNED BY public.llm_providers.id;


--
-- Name: reminders_triggers; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.reminders_triggers (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    description text,
    trigger_type character varying(50) DEFAULT 'reminder'::character varying NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    is_completed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.reminders_triggers OWNER TO rocky_admin;

--
-- Name: reminders_triggers_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.reminders_triggers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reminders_triggers_id_seq OWNER TO rocky_admin;

--
-- Name: reminders_triggers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.reminders_triggers_id_seq OWNED BY public.reminders_triggers.id;


--
-- Name: shopping_items; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.shopping_items (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_name character varying(255) NOT NULL,
    quantity integer DEFAULT 1,
    category character varying(100) DEFAULT 'General'::character varying,
    purchased boolean DEFAULT false,
    warranty_expiry date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.shopping_items OWNER TO rocky_admin;

--
-- Name: shopping_items_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.shopping_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shopping_items_id_seq OWNER TO rocky_admin;

--
-- Name: shopping_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.shopping_items_id_seq OWNED BY public.shopping_items.id;


--
-- Name: smart_home_devices; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.smart_home_devices (
    id integer NOT NULL,
    device_name character varying(255) NOT NULL,
    device_type character varying(100) NOT NULL,
    room character varying(100) NOT NULL,
    is_on boolean DEFAULT false,
    settings jsonb DEFAULT '{}'::jsonb,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.smart_home_devices OWNER TO rocky_admin;

--
-- Name: smart_home_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.smart_home_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.smart_home_devices_id_seq OWNER TO rocky_admin;

--
-- Name: smart_home_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.smart_home_devices_id_seq OWNED BY public.smart_home_devices.id;


--
-- Name: user_documents; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.user_documents (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    embedding public.vector(1536),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_documents OWNER TO rocky_admin;

--
-- Name: user_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.user_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_documents_id_seq OWNER TO rocky_admin;

--
-- Name: user_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.user_documents_id_seq OWNED BY public.user_documents.id;


--
-- Name: user_memories; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.user_memories (
    id integer NOT NULL,
    user_id integer NOT NULL,
    fact text NOT NULL,
    category character varying(50) DEFAULT 'preference'::character varying,
    confidence double precision DEFAULT 1.0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_memories OWNER TO rocky_admin;

--
-- Name: user_memories_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.user_memories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_memories_id_seq OWNER TO rocky_admin;

--
-- Name: user_memories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.user_memories_id_seq OWNED BY public.user_memories.id;


--
-- Name: user_notes; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.user_notes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    tags text[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_notes OWNER TO rocky_admin;

--
-- Name: user_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.user_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_notes_id_seq OWNER TO rocky_admin;

--
-- Name: user_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.user_notes_id_seq OWNED BY public.user_notes.id;


--
-- Name: user_subscriptions; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.user_subscriptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    service_name character varying(255) NOT NULL,
    billing_cycle character varying(50) DEFAULT 'monthly'::character varying NOT NULL,
    amount numeric(12,2) NOT NULL,
    next_billing_date date NOT NULL,
    category character varying(100) DEFAULT 'Subscription'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_subscriptions OWNER TO rocky_admin;

--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.user_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_subscriptions_id_seq OWNER TO rocky_admin;

--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.user_subscriptions_id_seq OWNED BY public.user_subscriptions.id;


--
-- Name: user_tasks; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.user_tasks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    priority character varying(10) DEFAULT 'P3'::character varying,
    category character varying(100) DEFAULT 'General'::character varying,
    due_date timestamp with time zone,
    is_completed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_tasks OWNER TO rocky_admin;

--
-- Name: user_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.user_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_tasks_id_seq OWNER TO rocky_admin;

--
-- Name: user_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.user_tasks_id_seq OWNED BY public.user_tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: rocky_admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password_hash text NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO rocky_admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: rocky_admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO rocky_admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rocky_admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: automation_routines id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.automation_routines ALTER COLUMN id SET DEFAULT nextval('public.automation_routines_id_seq'::regclass);


--
-- Name: calendar_events id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.calendar_events ALTER COLUMN id SET DEFAULT nextval('public.calendar_events_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: critical_vault id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.critical_vault ALTER COLUMN id SET DEFAULT nextval('public.critical_vault_id_seq'::regclass);


--
-- Name: financial_transactions id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.financial_transactions ALTER COLUMN id SET DEFAULT nextval('public.financial_transactions_id_seq'::regclass);


--
-- Name: llm_feature_routes id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_feature_routes ALTER COLUMN id SET DEFAULT nextval('public.llm_feature_routes_id_seq'::regclass);


--
-- Name: llm_providers id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_providers ALTER COLUMN id SET DEFAULT nextval('public.llm_providers_id_seq'::regclass);


--
-- Name: reminders_triggers id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.reminders_triggers ALTER COLUMN id SET DEFAULT nextval('public.reminders_triggers_id_seq'::regclass);


--
-- Name: shopping_items id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.shopping_items ALTER COLUMN id SET DEFAULT nextval('public.shopping_items_id_seq'::regclass);


--
-- Name: smart_home_devices id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.smart_home_devices ALTER COLUMN id SET DEFAULT nextval('public.smart_home_devices_id_seq'::regclass);


--
-- Name: user_documents id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_documents ALTER COLUMN id SET DEFAULT nextval('public.user_documents_id_seq'::regclass);


--
-- Name: user_memories id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_memories ALTER COLUMN id SET DEFAULT nextval('public.user_memories_id_seq'::regclass);


--
-- Name: user_notes id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_notes ALTER COLUMN id SET DEFAULT nextval('public.user_notes_id_seq'::regclass);


--
-- Name: user_subscriptions id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.user_subscriptions_id_seq'::regclass);


--
-- Name: user_tasks id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_tasks ALTER COLUMN id SET DEFAULT nextval('public.user_tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: automation_routines; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.automation_routines (id, routine_name, icon, description, actions, created_at) FROM stdin;
1	Good Morning	sun	Activates morning lights, sets HVAC to 23°C, unlocks interior, turns on air purifier.	[{"state": true, "settings": {"brightness": 100}, "device_name": "Living Room Main Lights"}, {"state": true, "settings": {"mode": "cool", "temperature": 23}, "device_name": "Primary HVAC Thermostat"}, {"state": true, "settings": {"brightness": 75}, "device_name": "Studio Ambient LED Strip"}]	2026-10-26 12:59:55.548915
2	Good Night	moon	Dims all interior lights, locks main entrance, sets HVAC night mode.	[{"state": false, "device_name": "Living Room Main Lights"}, {"state": false, "device_name": "Studio Ambient LED Strip"}, {"state": true, "device_name": "Main Entrance Smart Lock"}, {"state": true, "settings": {"mode": "eco", "temperature": 21}, "device_name": "Primary HVAC Thermostat"}]	2026-10-26 12:59:55.548915
3	Cyber Focus Mode	cpu	Sets studio lighting to Sci-Fi Cyan, turns off main living room lights.	[{"state": false, "device_name": "Living Room Main Lights"}, {"state": true, "settings": {"color": "cyan", "brightness": 100}, "device_name": "Studio Ambient LED Strip"}]	2026-10-26 12:59:55.548915
4	Security Lockdown	shield	Arms perimeter cameras, locks entrance, turns on outdoor floodlights.	[{"state": true, "device_name": "Main Entrance Smart Lock"}, {"state": true, "settings": {"motion_detect": true}, "device_name": "Perimeter Security Cameras"}]	2026-10-26 12:59:55.548915
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.calendar_events (id, user_id, title, description, location, start_time, end_time, attendees, agenda, action_items, recurrence_rule, category, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.conversations (id, user_id, role, content, "timestamp") FROM stdin;
1	2	user	Hello rocky how is the weather today	2026-10-30 13:44:29.287472
2	2	user	Hi	2026-10-30 13:46:59.305374
\.


--
-- Data for Name: critical_vault; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.critical_vault (id, user_id, data_category, encrypted_value, notes, created_at) FROM stdin;
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.financial_transactions (id, user_id, type, category, amount, merchant, transaction_date, notes, created_at) FROM stdin;
\.


--
-- Data for Name: llm_feature_routes; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.llm_feature_routes (id, feature_key, feature_name, description, primary_provider_id, primary_model, fallback_provider_id, fallback_model, system_prompt_override, temperature_override, max_tokens_override, updated_at) FROM stdin;
1	voice_agent	Real-Time Voice Assistant Dialogue	Low-latency conversational voice agent streaming audio in WebRTC sessions via LiveKit	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.361325
3	intent_action_dispatch	Intent Parsing & Action Dispatch	Natural language extraction for creating tasks, reminders, calendar entries, and smart home actions	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.374171
4	hitl_safety_guardrail	Human-in-the-Loop Safety Analysis	Evaluates high-risk destructive operations (file deletion, terminal execution) before staging	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.375947
5	memory_extraction	Long-Term Memory & User Facts	Extracts personal preferences, facts, and habits from conversation history into pgvector via Mem0	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.379908
6	calendar_agenda_generation	Meeting Agenda & Brief Synthesis	Generates structured meeting agendas, objectives, and discussion points	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.452725
7	daily_briefing_synthesis	Executive Morning Daily Briefing	Synthesizes weather, schedule, reminders, and news into a cohesive daily summary	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.463132
8	study_matrix_quiz	Study Matrix AI Quiz & Explanations	Generates interactive multiple-choice quizzes, answer explanations, and concept drill cards	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:17:35.467628
2	chat_text	Interactive Text Chat & Terminal	Streaming text chat responses over SSE and WebSockets in the HUD interface	1	qwen2.5:1.5b	\N	\N	\N	\N	\N	2026-10-27 12:18:01.468956
\.


--
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.llm_providers (id, name, provider_type, base_url, api_key_encrypted, default_model, available_models, temperature, max_tokens, timeout_seconds, is_active, is_system, created_at, updated_at) FROM stdin;
1	Local Ollama	ollama	http://ollama:11434	\N	qwen2.5:1.5b	[]	0.70	2048	60	t	t	2026-10-27 12:17:35.253647	2026-10-27 12:17:35.253647
\.


--
-- Data for Name: reminders_triggers; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.reminders_triggers (id, user_id, title, description, trigger_type, scheduled_at, is_completed, created_at) FROM stdin;
\.


--
-- Data for Name: shopping_items; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.shopping_items (id, user_id, item_name, quantity, category, purchased, warranty_expiry, created_at) FROM stdin;
\.


--
-- Data for Name: smart_home_devices; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.smart_home_devices (id, device_name, device_type, room, is_on, settings, updated_at) FROM stdin;
1	Living Room Main Lights	light	Living Room	t	{"color": "warm_white", "brightness": 80}	2026-10-26 12:59:55.547327
2	Primary HVAC Thermostat	thermostat	Entire Home	t	{"mode": "cool", "temperature": 22}	2026-10-26 12:59:55.547327
3	Main Entrance Smart Lock	lock	Entrance	t	{"auto_lock": true}	2026-10-26 12:59:55.547327
4	Studio Ambient LED Strip	light	Office	f	{"color": "cyan", "brightness": 100}	2026-10-26 12:59:55.547327
5	HEPA Air Purifier Pro	purifier	Bedroom	t	{"aqi": 12, "fan_speed": "auto"}	2026-10-26 12:59:55.547327
6	Perimeter Security Cameras	camera	Outdoor	t	{"recording": true, "motion_detect": true}	2026-10-26 12:59:55.547327
\.


--
-- Data for Name: user_documents; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.user_documents (id, user_id, title, content, embedding, created_at) FROM stdin;
\.


--
-- Data for Name: user_memories; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.user_memories (id, user_id, fact, category, confidence, created_at) FROM stdin;
\.


--
-- Data for Name: user_notes; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.user_notes (id, user_id, title, content, tags, created_at) FROM stdin;
\.


--
-- Data for Name: user_subscriptions; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.user_subscriptions (id, user_id, service_name, billing_cycle, amount, next_billing_date, category, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: user_tasks; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.user_tasks (id, user_id, title, description, priority, category, due_date, is_completed, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: rocky_admin
--

COPY public.users (id, username, password_hash, role, created_at) FROM stdin;
1	admin	$2b$12$dFxvScDwux3Abinsqsnac.sPO.iexdAvykLk1AmK6E00DKzoWfCbe	admin	2026-10-26 12:59:55.800948
2	Mani	$2b$12$lLCfJ9GyOmdfr3meWk3weOPnlDHbrdv5fY8ls9cX39S/.1QyjEq1K	admin	2026-10-26 13:14:51.608818
\.


--
-- Name: automation_routines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.automation_routines_id_seq', 4, true);


--
-- Name: calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.calendar_events_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.conversations_id_seq', 2, true);


--
-- Name: critical_vault_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.critical_vault_id_seq', 1, false);


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.financial_transactions_id_seq', 1, false);


--
-- Name: llm_feature_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.llm_feature_routes_id_seq', 104, true);


--
-- Name: llm_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.llm_providers_id_seq', 7, true);


--
-- Name: reminders_triggers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.reminders_triggers_id_seq', 1, false);


--
-- Name: shopping_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.shopping_items_id_seq', 1, false);


--
-- Name: smart_home_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.smart_home_devices_id_seq', 6, true);


--
-- Name: user_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.user_documents_id_seq', 1, false);


--
-- Name: user_memories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.user_memories_id_seq', 1, false);


--
-- Name: user_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.user_notes_id_seq', 1, false);


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.user_subscriptions_id_seq', 1, false);


--
-- Name: user_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.user_tasks_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rocky_admin
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: automation_routines automation_routines_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.automation_routines
    ADD CONSTRAINT automation_routines_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: critical_vault critical_vault_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.critical_vault
    ADD CONSTRAINT critical_vault_pkey PRIMARY KEY (id);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: llm_feature_routes llm_feature_routes_feature_key_key; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_feature_routes
    ADD CONSTRAINT llm_feature_routes_feature_key_key UNIQUE (feature_key);


--
-- Name: llm_feature_routes llm_feature_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_feature_routes
    ADD CONSTRAINT llm_feature_routes_pkey PRIMARY KEY (id);


--
-- Name: llm_providers llm_providers_name_key; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_name_key UNIQUE (name);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (id);


--
-- Name: reminders_triggers reminders_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.reminders_triggers
    ADD CONSTRAINT reminders_triggers_pkey PRIMARY KEY (id);


--
-- Name: shopping_items shopping_items_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_pkey PRIMARY KEY (id);


--
-- Name: smart_home_devices smart_home_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.smart_home_devices
    ADD CONSTRAINT smart_home_devices_pkey PRIMARY KEY (id);


--
-- Name: user_documents user_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_documents
    ADD CONSTRAINT user_documents_pkey PRIMARY KEY (id);


--
-- Name: user_memories user_memories_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_memories
    ADD CONSTRAINT user_memories_pkey PRIMARY KEY (id);


--
-- Name: user_notes user_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_notes
    ADD CONSTRAINT user_notes_pkey PRIMARY KEY (id);


--
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: user_tasks user_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_tasks
    ADD CONSTRAINT user_tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: calendar_events calendar_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: critical_vault critical_vault_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.critical_vault
    ADD CONSTRAINT critical_vault_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: financial_transactions financial_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: llm_feature_routes llm_feature_routes_fallback_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_feature_routes
    ADD CONSTRAINT llm_feature_routes_fallback_provider_id_fkey FOREIGN KEY (fallback_provider_id) REFERENCES public.llm_providers(id) ON DELETE SET NULL;


--
-- Name: llm_feature_routes llm_feature_routes_primary_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.llm_feature_routes
    ADD CONSTRAINT llm_feature_routes_primary_provider_id_fkey FOREIGN KEY (primary_provider_id) REFERENCES public.llm_providers(id) ON DELETE RESTRICT;


--
-- Name: reminders_triggers reminders_triggers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.reminders_triggers
    ADD CONSTRAINT reminders_triggers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shopping_items shopping_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_documents user_documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_documents
    ADD CONSTRAINT user_documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_memories user_memories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_memories
    ADD CONSTRAINT user_memories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notes user_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_notes
    ADD CONSTRAINT user_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_subscriptions user_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_tasks user_tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rocky_admin
--

ALTER TABLE ONLY public.user_tasks
    ADD CONSTRAINT user_tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ANljeK0JClRIe1d95VUe2qf7hrgoZ1dlhifW6NwRbXiKFov25nVjwd0A4Z2XjPw

